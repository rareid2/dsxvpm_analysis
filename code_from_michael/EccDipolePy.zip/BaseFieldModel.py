# -*- coding: utf-8 -*-
#
# BaseFieldModel.py
#
# Base class definition for geomagnetic field model objects.

# Michael Starks     AFRL/RVBX      10 Feb 2021


class BaseFieldModel:
    """Base class definition for geomagnetic field objects"""

    class Error(Exception):
        """Base class for this class's exceptions"""
        pass


    class InvalidFieldModel(Error):
        """Exception indicating that a specified field model cannot be created.
                Attributes:
                    expression -- model ID
                    message -- explanation of the error
        """
        def __init__(self, expression, message=None):
            self.expression = expression
            if (message is not None):
                self.message = message
            self.message = 'The specified model is invalid.'


    @classmethod
    def GetModelID(cls):
        """Returns a string identifier for the model"""
        pass


    @classmethod
    def LocalField(cls,r):
        """Returns the local field intensity [T] and Cartesian direction [Mm] at location geocentric Cartesian location r [Mm]"""
        pass

    @classmethod
    def ComputeAngleToField(cls, r, v):
        """Returns the angle [deg] between the local magnetic field at location r [Mm] and the vector v"""
        import numpy as np
        if (v.ndim < 2):
            v = np.array(v, ndmin=2)
        if (v.shape[1] != 3):
            v = np.reshape(v, (-1,3))

        _Babs, Bdir = cls.LocalField(r)
        tmpNorm = np.linalg.norm(v)
        tmpVal = np.dot(v, np.transpose(Bdir))[0,0] / tmpNorm
        # Clamp at +/- 1 to avoid errors values due to numerical noise.
        kBangle = np.degrees(np.arccos(np.max((np.min((1.0, tmpVal)), -1.0))))
        return kBangle


    def StoreParameters(self, h5group):
        """Stores model ID and initialization parameters to the provided HDF5 group"""
        pass


    def GetParametersDict(self):
        """Returns a dictionary object containing the model ID and initialization parameters"""
        pass


    # FACTORY METHODS
    # Must add entries in these two functions for all new models

    @classmethod
    def CreateFromHDF5(cls, h5group):
        """Create and return a field model object described by the HDF5 field-model group provided."""
        import h5py
        from FieldModels.EccDipole import EccDipole
        from FieldModels.EccDipole_AmpTrace import EccDipole_AmpTrace
        
        modelId = h5group.attrs['model-id']
        if (modelId == 'ecc-dipole'):
            model = EccDipole()
        elif (modelId == 'ecc-dipole-amptrace'):
            model = EccDipole_AmpTrace()
        else:
            raise cls.InvalidFieldModel(modelId)

        return model


    @classmethod
    def CreateFromDict(cls, dict):
        """Create and return a field model object described by the dictionary field-model information provided."""
        from FieldModels.EccDipole import EccDipole
        from FieldModels.EccDipole_AmpTrace import EccDipole_AmpTrace
        modelId = dict['model-id']
        if (modelId == 'ecc-dipole'):
            model = EccDipole()
        elif (modelId == 'ecc-dipole-amptrace'):
            model = EccDipole_AmpTrace()
        else:
            raise cls.InvalidFieldModel(modelId)
            
        return model