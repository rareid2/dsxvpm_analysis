# -*- coding: utf-8 -*-
#
# Constants
#
# Physical constants

# Michael Starks        AFRL/RVBX     21 Feb 2021

class Constants():
    me = 9.1093826e-31              # electron mass [kg]
    JeV = 1.60217653e-19            # electron charge [C]
    e0 = 8.854187817e-12            # permittivity of free space [F/m]
    u0 = 1.25663706e-6              # permeability of free space [H/m]
    c = 2.99792458e+8               # speed of light in vacuum [m/s]
    EarthRadius = 6.3712            # radius of the Earth [Mm]
    HplusMass = 1840.0              # mass of hydrogen ion [electon masses]
    OplusMass = 1840.0 * 16.0       # mass of oxygen ion [electron masses]
    mp = 1.6726231e-27              # proton mass [kg]
    g = 9.80665                     # gravitational acceleration [m/s]
    k = 1.38064852e-23              # Boltzmann's constant [m^2 kg / s^2 K]
    