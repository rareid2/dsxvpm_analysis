# -*- coding: utf-8 -*-
#
# VectorSph2Cart.py
#
# Convert a spherical vector v (r, lat, lon) at specific Cartesian location r [Mm] to a Cartesian vector (x , y, z)
#

# Michael Starks     AFRL/RVBX      11 Feb 2021


def VectorSph2Cart(r, v):
    """Convert a spherical vector v (r, lat, lon) at specific Cartesian location r [Mm] to a Cartesian vector (x , y, z)"""
    import numpy as np
    import math
    ZERTOL = 1e-24
    
    if (r.ndim < 2):
        r = np.array(r, ndmin=2)
    if (r.shape[1] != 3):
        r = np.reshape(r, (-1,3))
    if (v.ndim < 2):
        v = np.array(v, ndmin=2)
    if (v.shape[1] != 3):
        v = np.reshape(v, (-1,3))

    # Compute the phi vector
    rp_len2 = r[0,0]*r[0,0] + r[0,1]*r[0,1]
    d = math.sqrt(rp_len2)
    if (d > ZERTOL):
        phi_dir = np.array((-r[0,1]/d, r[0,0]/d, 0.0),ndmin=2)
    else:
        phi_dir = np.array((1.0, 0.0, 0.0),ndmin=2)
  
    # Compute the r vector
    d = math.sqrt(rp_len2 + r[0,2]*r[0,2])
    r_dir = r / d

    # Compute the theta vector
    theta_dir = np.empty((1,3))
    theta_dir[0,0] = r_dir[0,1]*phi_dir[0,2] - r_dir[0,2]*phi_dir[0,1]
    theta_dir[0,1] = r_dir[0,2]*phi_dir[0,0] - r_dir[0,0]*phi_dir[0,2]
    theta_dir[0,2] = r_dir[0,0]*phi_dir[0,1] - r_dir[0,1]*phi_dir[0,0]

    # Convert the vector to Cartesian
    v_cart = np.array((v[0,0]*r_dir[0,0] + v[0,1]*theta_dir[0,0] + v[0,2]*phi_dir[0,0],
                       v[0,0]*r_dir[0,1] + v[0,1]*theta_dir[0,1] + v[0,2]*phi_dir[0,1],
                       v[0,0]*r_dir[0,2] + v[0,1]*theta_dir[0,2] + v[0,2]*phi_dir[0,2]), ndmin=2)

    return(v_cart)


if __name__ == "__main__":
    import numpy as np
    import time

    # Test accuracy
    r = np.array([[1.0,0.0,0.0],[0.0,1.0,0.0],[0.0,0.0,1.0],[1.0,1.0,0.0],[0.0,1.0,1.0],[-1.0,-1.0,0.0]])
    v = np.array([[1.0,0.0,0.0],[0.0,1.0,0.0],[0.0,0.0,1.0]])
    for ind in np.arange(0,r.shape[0]):
        print('For x={0:3.1f}  y={1:3.1f}  z={2:3.1f}:'.format(r[ind,0],r[ind,1],r[ind,2]))
        for ind2 in np.arange(0,v.shape[0]):
            b = VectorSph2Cart(r[ind,:],v[ind2,:])
            print('   r={0:3.1f}  t={1:3.1f}  p={2:3.1f}  yields x={3:3.1f}  y={4:3.1f}  z={5:3.1f}'.format(v[ind2,0],v[ind2,1],v[ind2,2],b[0,0],b[0,1],b[0,2]))
    
    # Timing
    cum1 = 0.0
    for ind in np.arange(0, 10000):
        r = 2.0 * np.random.random_sample((1,3)) - 1.0
        v = 2.0 * np.random.random_sample((1,3)) - 1.0
        tic1 = time.perf_counter()
        b = VectorSph2Cart(r,v)
        toc1 = time.perf_counter()
        cum1 += (toc1 - tic1)
    print('VectorCart2Sph elapsed: {0:f}'.format(cum1))
    
    pass
