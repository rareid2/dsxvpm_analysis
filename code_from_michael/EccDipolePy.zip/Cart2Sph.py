# -*- coding: utf-8 -*-
#
# Cart2Sph.py
#
# Convert a Cartesian coordinate [Mm] to a spherical representation
#  (r [Mm], lat [deg], lon [deg])
#

# Michael Starks     AFRL/RVBX      10 Feb 2021

def Cart2Sph(r):
    """Convert a Cartesian coordinate [Mm] to a spherical representation (r[Mm], lat [deg], lon [deg]). Must be a row vector or a matrix of row vectors."""
    # This function has been vectorized
    import numpy as np
    ZERTOL = 1e-24
    
    if (r.ndim < 2):
        r = np.array(r, ndmin=2)
    if (r.shape[1] != 3):
        r = np.reshape(r, (-1,3))

    if (r.shape[1] < 50):
        # Non-Numpy version is faster for smaller lists of coordinates (and especially single coordinates)
        import math
        r_sph = np.empty((r.shape))
        for i in np.arange(0, r.shape[0]):
            rp_len2 = r[i,0]*r[i,0] + r[i,1]*r[i,1]
            r_sph[i,0] = math.sqrt(rp_len2 + r[i,2]*r[i,2])
            if (r_sph[i,0] > ZERTOL):
                r_sph[i,1] = math.degrees(math.asin(r[i,2] / r_sph[i,0]))
            else:
                r_sph[i,1] = 0.0
            rp_len = math.sqrt(rp_len2)
            if (rp_len > ZERTOL):
                r_sph[i,2] = math.degrees(math.acos(r[i,0] / rp_len))
            else:
                r_sph[i,2] = 0.0
            if (r[i,1] < 0.0):
                r_sph[i,2] = -r_sph[i,2]

    else:
        # Numpy version is faster for larger lists of coordinates
        r_len = np.sqrt(np.sum(np.square(r),axis=1))
        lat = np.zeros((r.shape[0],1))
        rlengtzertol = np.array(r_len > ZERTOL).flatten()
        if (np.any(rlengtzertol)):
            lat[rlengtzertol] = np.reshape((np.arcsin(r[rlengtzertol,2] / r_len[rlengtzertol])),lat.shape)
        
        rp_len = np.sqrt(np.sum(np.square(r[:,0:2]),axis=1))
        lon = np.zeros((r.shape[0],1))
        rplengtzertol = np.array(rp_len > ZERTOL)
        if (np.any(rplengtzertol)):
            for ind in np.arange(0, lon.shape[0]):
                if (rplengtzertol[ind]):
                    lon[ind,:] = np.arccos(r[ind,0] / rp_len[ind])
        r1lt0 = r[:,1] < 0.0
        lon[r1lt0] = -lon[r1lt0]
        r_sph = np.column_stack((r_len, np.degrees(lat), np.degrees(lon)))

    return r_sph



if __name__ == "__main__":
    import numpy as np
    import time

    # Direct comparison
    a = np.array([[1.0,0.0,0.0],[0.0,1.0,0.0],[0.0,0.0,1.0],[1.0,1.0,0.0],[0.0,1.0,1.0],[-1.0,-1.0,0.0]])
    for ind in np.arange(0,a.shape[0]):
        b = Cart2Sph(a[ind,:])
        print('x={0:3.1f}  y={1:3.1f}  z={2:3.1f}  yields r={3:3.1f}  lat={4:5.1f}   lon={5:6.1f}'.format(a[ind,0],a[ind,1],a[ind,2],b[0,0],b[0,1],b[0,2]))
    
    # Timing
    cum1 = 0.0
    for ind in np.arange(0, 10000):
        a = 2.0 * np.random.random_sample((1,3)) - 1.0
        tic1 = time.perf_counter()
        b = Cart2Sph(a)
        toc1 = time.perf_counter()
        cum1 += (toc1 - tic1)
    print('Cart2Sph elapsed: {0:f}'.format(cum1))

    pass
